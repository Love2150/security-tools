﻿# PCAP Quick Profiler
Fast PCAP triage with DNS/TLS focus, beaconing suspects, and HTML report (with dark mode).
